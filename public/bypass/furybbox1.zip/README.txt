Safe placeholder archive for V2 server/download testing.
Replace only with ordinary non-executable resources you are authorized to distribute.
