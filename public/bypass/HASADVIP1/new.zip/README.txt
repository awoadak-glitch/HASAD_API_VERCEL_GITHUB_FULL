Safe placeholder archive for API/deployment testing.
Replace only with ordinary non-executable application resources you are authorized to distribute.
